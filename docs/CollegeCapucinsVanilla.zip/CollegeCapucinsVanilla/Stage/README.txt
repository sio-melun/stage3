Au(x) futur(e/s/es) stagiaire(s), ce fichier README regroupe un certains nombres de point que nous n'avons pas fini, des points important
ou des choses qui nous semble intéressant à dévelloper. B

Choses non terminées:

- Certaines des pages pour l'admin (listeSansStage.php, listeAvecStage.php, detailsTut.php, detailsEleve.php et detailsProf.php)
sont redontante avec les pages prof portant le même nom. On avait commencer a faire des redirections vers ces âges pour l'admins mais
nous n'avons pas pu terminer ça a cause d'un manque de temps.

- La page infoTuteur est redondante avec detailsTut.php mais un des id passé dans ces deux pages n'est pas le même

- Faire une page pour le layout pour tout centraliser.

Points importants:

- Il y a un fichier humans.txt, ce fichier est issu d'une initiative (http://humanstxt.org/FR), ajoutez y votre/vos nom(s) ansssi que dans
la partie footer des pages si vous le souhaiter!

- L'administrateur se connecte par les pages profs

- Les professeurs ont accès au formulaire pour entrer un stage mais ne pourront jamais valider.

- De base ce site sert uniquement pour les élèves avec une liste d'entreprise mais nous sommes aller plus loin que de faire une
simple liste. Quand nous avons conçu la BDD nous avons ajouter toute une partie professeur pour permettre un gestion des professeurs
tuteurs des élèves qu'ils vont suivre en stage. MAIS nous avons par la suite appris que Pronote permettais la prise en charge de cette
partie et donc que cette partie ne serais pas utilisée...

Idée pour de possibles améliorations:

- Ajouter un champ de commentaires dans la table stage afin de pouvoir y mettre des informations sur le déroulé du stage.

- Ajouter une messagerie interne ou par le biais de boite mail google.


